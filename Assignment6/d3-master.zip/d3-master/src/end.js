  if (typeof define === "function" && define.amd) this.d3 = d3, define(d3);
  else if (typeof module === "object" && module.exports) module.exports = d3;
  else this.d3 = d3;
}();
